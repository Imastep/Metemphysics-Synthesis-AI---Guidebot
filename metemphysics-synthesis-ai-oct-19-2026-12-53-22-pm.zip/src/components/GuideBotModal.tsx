import React, { useState, useRef, useEffect } from "react";
import {
  Sparkles,
  Check,
  X,
  BookOpen,
  Layers,
  Calculator,
  Atom,
  Cpu,
  Flame,
  BarChart,
  Dna,
  Compass,
  FileText,
  Database,
  Activity,
  Hash,
  Network,
  RotateCcw,
  Send,
  HelpCircle,
  ChevronRight,
  ChevronLeft,
  Zap,
  Scale,
  Volume2,
  VolumeX,
  Play,
  Search,
  ExternalLink,
  Sliders,
  Radio
} from "lucide-react";

export interface GuideBotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onToggleGuide?: (active: boolean) => void;
  isGuideActive?: boolean;
  activeStep: number;
  onSelectStep: (step: number) => void;
  onNavigateToSection?: (section: "chat" | "ontology" | "states" | "formulas" | "harmonics" | "systems", subId?: string) => void;
  onLaunchPanel?: (panelId: string) => void;
  onInjectPrompt?: (prompt: string) => void;
}

export default function GuideBotModal({
  isOpen,
  onClose,
  activeStep,
  onSelectStep,
  onNavigateToSection,
  onLaunchPanel,
  onInjectPrompt,
}: GuideBotModalProps) {
  const [showCheckConfirm, setShowCheckConfirm] = useState(false);
  
  // Interactive Step 1 Category Filter
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  
  // Interactive Step 2 J/S Slider State
  const [jsRatio, setJsRatio] = useState<number>(5);
  
  // Interactive Step 3 Formula State
  const [calcTimeT, setCalcTimeT] = useState<number>(10);
  const [calcEntropyS, setCalcEntropyS] = useState<number>(52.8);
  const [calcCMode, setCalcCMode] = useState<"solfeggio" | "standard" | "planck">("solfeggio");

  // Interactive Step 4 Audio Synthesizer State
  const [activeFrequency, setActiveFrequency] = useState<number | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Interactive Step 5 Systems Lab Search
  const [systemSearch, setSystemSearch] = useState<string>("");

  useEffect(() => {
    return () => {
      if (audioCtxRef.current && audioCtxRef.current.state !== "closed") {
        try {
          audioCtxRef.current.close();
        } catch {}
      }
    };
  }, []);

  if (!isOpen) return null;

  // Sound generator helper for Step 4
  const playSolfeggioTone = (freq: number) => {
    try {
      if (!audioCtxRef.current || audioCtxRef.current.state === "closed") {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        audioCtxRef.current = new AudioCtx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") {
        ctx.resume();
      }

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      // Smooth attack & decay
      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 1.5);

      setActiveFrequency(freq);
      setIsPlayingAudio(true);

      setTimeout(() => {
        setIsPlayingAudio(false);
      }, 1500);
    } catch (e) {
      console.warn("Audio playback not supported in this environment", e);
    }
  };

  const handleSendPromptDirectly = (prompt: string) => {
    if (onInjectPrompt) {
      onInjectPrompt(prompt);
      onClose();
    }
  };

  const steps = [
    {
      id: "chat",
      title: "Interactive AI Terminal & Cog Engine",
      subtitle: "Live query transmission, multi-modal reasoning calibrations, and contextual chips",
      icon: Sparkles,
      color: "text-orange-400 border-orange-500/40 bg-orange-950/20",
    },
    {
      id: "ontology",
      title: "Ontology Directory & Dialectics",
      subtitle: "Filter the 5 core ontological domains, tensor synergies & contradiction resolution",
      icon: BookOpen,
      color: "text-amber-300 border-amber-500/40 bg-amber-950/20",
    },
    {
      id: "states",
      title: "J/S Consciousness Resonance Matrix",
      subtitle: "Live state slider evaluating Will (J) vs Entropy (S) across David Hawkins' H=1-1000 field",
      icon: Layers,
      color: "text-purple-400 border-purple-500/40 bg-purple-950/20",
    },
    {
      id: "formulas",
      title: "Interactive T × S = C Calculator",
      subtitle: "Live thermodynamic simulator computing subjective dilation and molar entropy capacity",
      icon: Calculator,
      color: "text-orange-400 border-orange-500/40 bg-orange-950/20",
    },
    {
      id: "harmonics",
      title: "Interactive Solfeggio Synthesizer",
      subtitle: "Play pure acoustic sine tones (174-963 Hz), Pythagorean harmonic ratios & genre mappings",
      icon: Atom,
      color: "text-teal-400 border-teal-500/40 bg-teal-950/20",
    },
    {
      id: "systems",
      title: "Systems Lab Interactive Directory",
      subtitle: "Filter, explore descriptions, and directly launch all 12 thermodynamic & 5D solvers",
      icon: Cpu,
      color: "text-orange-400 border-orange-500/40 bg-orange-950/20",
    },
  ];

  const current = steps[activeStep] || steps[0];

  const handleKeepGuide = () => {
    setShowCheckConfirm(true);
    setTimeout(() => {
      setShowCheckConfirm(false);
      onClose();
    }, 450);
  };

  const systemsLabItems = [
    { id: "chakra", name: "Music & Chakra Atlas", icon: Flame, desc: "Solfeggio tones & human bio-field frequencies (174-963Hz). Couples acoustics with EEG bands.", tag: "Bio-Acoustics" },
    { id: "entropy", name: "Entropy Periodic Table", icon: BarChart, desc: "Accurate thermodynamic ledger of standard molar entropy (S°) across elements and states of matter.", tag: "Thermodynamics" },
    { id: "bio", name: "Biological Entropy Atlas", icon: Dna, desc: "Metabolic scaling, ATP synthesis, protein folding, and ecosystem dissipation limits under Clausius laws.", tag: "Biophysics" },
    { id: "systems", name: "All Systems Database", icon: Compass, desc: "Comparative matrix matching 18 developmental scales (Wilber AQAL, Aurobindo, Maslow, Kabbalah, Chakras).", tag: "Integral Typology" },
    { id: "calc", name: "Metemphysics Calculator", icon: Calculator, desc: "Six dynamic 5D solvers computing tensor decay, boundary horizons, and conscious time dilation.", tag: "5D Math" },
    { id: "codereader", name: "Casting Personal Code", icon: FileText, desc: "Evaluates birthdates or personal parameters to calculate individual T × S = C resonance and generate verified certificates.", tag: "Personal Code" },
    { id: "reftables", name: "References Tables DB", icon: Database, desc: "Searchable compendium of physical constants, cosmological boundaries, and historical sacred traditions.", tag: "Constants" },
    { id: "reftools", name: "Tools of References", icon: Activity, desc: "Acoustic signal generator, pure tone Solfeggio oscillator, and real-time waveform testers.", tag: "Signal Generator" },
    { id: "hawkinsprogram", name: "David Hawkins Program", icon: Cpu, desc: "Logarithmic calibration of attractor fields (H=1 to 1000) modeling human moral and spiritual evolution.", tag: "Attractor Scale" },
    { id: "celestialscale", name: "Celestial Scale (FMCS)", icon: Sparkles, desc: "Macrocosmic mass tracker calculating stellar outputs, planetary densities, and Schwarzschild radii.", tag: "Astrophysics" },
    { id: "numerology", name: "Numerology Scale", icon: Hash, desc: "Pythagorean single-digit reduction grid (0-9) mapping sacred geometries and archetypal descriptors.", tag: "Archetypes" },
    { id: "knodegraph", name: "Knode Graph Routing", icon: Network, desc: "Topological node visualizer tracking real-time semantic gateways and knowledge graph associations.", tag: "Topology" },
  ];

  // Filtered Systems Lab items for Step 5
  const filteredSystems = systemsLabItems.filter((item) =>
    item.name.toLowerCase().includes(systemSearch.toLowerCase()) ||
    item.desc.toLowerCase().includes(systemSearch.toLowerCase()) ||
    item.tag.toLowerCase().includes(systemSearch.toLowerCase())
  );

  // Solfeggio tones for Step 4
  const solfeggioFrequencies = [
    { freq: 174, name: "Foundation & Safety", band: "Sub-Physical", chakra: "Earth Ground" },
    { freq: 285, name: "Cellular Healing", band: "Morphogenetic", chakra: "Quantum Field" },
    { freq: 396, name: "Liberation from Guilt", band: "Muladhara", chakra: "Root Chakra" },
    { freq: 417, name: "Facilitating Change", band: "Svadhisthana", chakra: "Sacral Chakra" },
    { freq: 528, name: "Transformation & DNA Repair", band: "Manipura", chakra: "Solar Plexus" },
    { freq: 639, name: "Harmonious Relationships", band: "Anahata", chakra: "Heart Chakra" },
    { freq: 741, name: "Intuition & Awakening", band: "Vishuddha", chakra: "Throat Chakra" },
    { freq: 852, name: "Spiritual Order", band: "Ajna", chakra: "Third Eye" },
    { freq: 963, name: "Divine Consciousness", band: "Sahasrara", chakra: "Crown Chakra" },
  ];

  // Helper for Step 2 J/S state description
  const getJsStateDetails = (ratio: number) => {
    if (ratio >= 50) {
      return {
        state: "REVELATION",
        hVal: "1000",
        color: "text-purple-400 border-purple-500/50 bg-purple-950/30",
        desc: "Absolute timeless communion with invariant C; subjective time ceases to degrade into entropy.",
      };
    } else if (ratio >= 10) {
      return {
        state: "MYSTICAL CLARITY",
        hVal: "600 - 850",
        color: "text-indigo-400 border-indigo-500/50 bg-indigo-950/30",
        desc: "Transpersonal flow, awakened intentionality, high spiritual coherence, and nondual perception.",
      };
    } else if (ratio >= 1) {
      return {
        state: "EUDAIMONIA",
        hVal: "500 - 540",
        color: "text-emerald-400 border-emerald-500/50 bg-emerald-950/30",
        desc: "High biological negentropy, unconditional love, systemic synthesis, and intellectual peace.",
      };
    } else if (ratio >= 0) {
      return {
        state: "TIPPING POINT",
        hVal: "200 - 250",
        color: "text-amber-400 border-amber-500/50 bg-amber-950/30",
        desc: "Critical symmetric equilibrium between Courage/Acceptance and environmental friction.",
      };
    } else if (ratio >= -20) {
      return {
        state: "SUFFERING & FRICTION",
        hVal: "30 - 175",
        color: "text-red-400 border-red-500/50 bg-red-950/30",
        desc: "Active local entropy expansion, metabolic resistance, guilt, pride, or survival fragmentation.",
      };
    } else {
      return {
        state: "DISSOLUTION",
        hVal: "20",
        color: "text-gray-400 border-gray-700 bg-gray-950/40",
        desc: "Total system breakdown; system energy is dissipated into chaotic background environmental vacuum.",
      };
    }
  };

  const jsDetails = getJsStateDetails(jsRatio);

  // Formula calculations for Step 3
  const cTargetValue = calcCMode === "solfeggio" ? 528 : calcCMode === "standard" ? 299792458 : 1;
  const computedProduct = (calcTimeT * calcEntropyS).toFixed(2);
  const derivedEntropy = (cTargetValue / Math.max(0.001, calcTimeT)).toFixed(2);
  const derivedTime = (cTargetValue / Math.max(0.001, calcEntropyS)).toFixed(4);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl xl:max-w-6xl bg-[#090604] border-2 border-orange-500/50 rounded-2xl shadow-[0_0_60px_rgba(255,95,0,0.3)] flex flex-col h-[92vh] max-h-[92vh] overflow-hidden">
        
        {/* Header Bar */}
        <div className="px-5 py-4 bg-gradient-to-r from-orange-950/40 via-[#130b05] to-[#090604] border-b border-orange-500/30 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-orange-500/20 border border-orange-500/50 flex items-center justify-center text-orange-400 shadow-[0_0_18px_rgba(255,95,0,0.35)]">
              <Sparkles className="w-6 h-6 text-orange-400" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <span className="font-serif font-bold text-base sm:text-lg text-white tracking-widest uppercase">
                  Metemphysics Guide Bot
                </span>
                <span className="px-2.5 py-0.5 rounded text-[10.5px] font-mono font-bold uppercase bg-orange-500/25 text-orange-300 border border-orange-500/50">
                  Interactive Module {activeStep + 1} of {steps.length}
                </span>
              </div>
              <p className="text-xs font-mono text-gray-300 mt-0.5">
                Interactive walkthrough, live calculators &amp; systems simulator
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-lg bg-black/60 border border-orange-500/40 text-gray-300 hover:text-white hover:border-orange-500 transition-all flex items-center justify-center cursor-pointer shadow-sm active:scale-95"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Step Selector Pills with rich tooltips appearing ABOVE */}
        <div className="px-4 py-3 bg-[#060402] border-b border-orange-500/20 flex flex-wrap items-center justify-between gap-2.5 overflow-visible relative z-30 flex-shrink-0">
          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap w-full">
            {steps.map((st, idx) => {
              const isCurrent = activeStep === idx;
              const stepTipPos = idx === 0 ? "left-0 translate-x-0" : idx >= steps.length - 2 ? "right-0 left-auto translate-x-0" : "left-1/2 -translate-x-1/2";
              const stepArrowPos = idx === 0 ? "left-6" : idx >= steps.length - 2 ? "right-6 left-auto" : "left-1/2 -translate-x-1/2";
              return (
                <div key={st.id} className="relative group/steppill flex-shrink-0 flex-1 sm:flex-initial">
                  <button
                    onClick={() => {
                      onSelectStep(idx);
                      if (onNavigateToSection) {
                        onNavigateToSection(st.id as any);
                      }
                    }}
                    className={`w-full px-3.5 py-2 rounded-lg text-xs font-mono uppercase tracking-wider flex items-center justify-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                      isCurrent
                        ? "bg-gradient-to-r from-orange-500 to-amber-500 text-black font-extrabold shadow-[0_0_14px_rgba(255,95,0,0.45)]"
                        : "bg-[#110b06] text-gray-300 hover:text-orange-300 hover:bg-orange-950/40 border border-orange-500/20"
                    }`}
                  >
                    <span>{idx + 1}. {st.id.toUpperCase()}</span>
                  </button>
                  {/* Step tooltip appearing IN FRONT below the button */}
                  <span className={`pointer-events-none absolute top-full mt-2.5 w-64 sm:w-80 p-3.5 bg-black border border-orange-500/60 text-xs text-[#dacbb6] font-mono rounded-xl shadow-[0_10px_40px_rgba(0,0,0,1)] opacity-0 group-hover/steppill:opacity-100 transition-opacity duration-200 z-[999] text-left leading-normal whitespace-normal ${stepTipPos}`}>
                    <div className="flex items-center justify-between border-b border-orange-500/30 pb-1.5 mb-1.5">
                      <strong className="text-orange-400 text-xs uppercase tracking-wider font-bold">
                        {idx + 1}. {st.title}
                      </strong>
                      <span className="text-[10px] text-amber-300 font-mono font-bold px-1.5 py-0.5 rounded bg-orange-500/20 border border-orange-500/30">
                        SECTION {idx + 1}
                      </span>
                    </div>
                    <span className="text-[12.5px] text-[#faf6f0] leading-relaxed font-sans block mb-1">
                      {st.subtitle}
                    </span>
                    <span className="text-[10.5px] text-gray-400 font-mono block">
                      Click to navigate to this interactive module
                    </span>
                    <span className={`absolute bottom-full border-x-4 border-x-transparent border-b-4 border-b-orange-500/60 ${stepArrowPos}`} />
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 custom-scroll bg-[#0a0705]">
          
          {/* Step Banner */}
          <div className="relative p-4 sm:p-5 bg-gradient-to-r from-orange-950/30 via-black to-black border border-orange-500/30 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-xs font-mono uppercase font-bold text-orange-400 tracking-widest block">
                INTERACTIVE MODULE {activeStep + 1} / {steps.length}
              </span>
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#eeeae4] mt-1">
                {current.title}
              </h3>
              <p className="text-xs sm:text-sm font-mono text-gray-300 mt-1">
                {current.subtitle}
              </p>
            </div>
            <span className="text-[12px] font-mono text-amber-300 bg-orange-500/15 border border-orange-500/30 px-3 py-1.5 rounded-lg self-start sm:self-auto flex items-center gap-1.5 flex-shrink-0">
              <Zap className="w-3.5 h-3.5 text-orange-400" />
              <span>Interactive Live Mode</span>
            </span>
          </div>

          {/* STEP 0: AI CHAT BOX FUNCTIONS & INTERACTIVE QUERY SAMPLES */}
          {activeStep === 0 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-black/60 border border-orange-500/20 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2 text-orange-400 font-mono text-sm font-bold uppercase">
                    <Send className="w-4 h-4" />
                    <span>Query Transmission Bar</span>
                  </div>
                  <p className="text-xs sm:text-[14px] font-serif text-[#eeeae4] leading-relaxed">
                    Type your inquiry into the bottom terminal bar and press <strong>Enter</strong> or <strong>Transmit</strong>. You can ask anything from fundamental physics constants to spiritual nonduality, consciousness boundaries, or cellular metabolism.
                  </p>
                </div>

                <div className="p-4 bg-black/60 border border-orange-500/20 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2 text-orange-400 font-mono text-sm font-bold uppercase">
                    <Atom className="w-4 h-4" />
                    <span>Metemphysics Cog Modes</span>
                  </div>
                  <p className="text-xs sm:text-[14px] font-serif text-[#eeeae4] leading-relaxed">
                    Use the <strong>Metemphysics Cog</strong> dropdown in the top bar to switch reasoning models:
                  </p>
                  <ul className="text-xs font-mono text-gray-300 space-y-1 list-disc list-inside">
                    <li><strong className="text-orange-300">Basic Engine</strong>: Balanced holistic synthesis.</li>
                    <li><strong className="text-gray-100">Omniscient Mode</strong>: High cosmic &amp; mathematical rigor.</li>
                    <li><strong className="text-cyan-300">Socratic Guide</strong>: Inquiry-driven philosophical dialogue.</li>
                    <li><strong className="text-amber-300">Strict Calculator</strong>: Exact numerical derivations &amp; formulas.</li>
                    <li><strong className="text-emerald-300">Research &amp; Discovery</strong>: Academic citations &amp; references.</li>
                  </ul>
                </div>
              </div>

              {/* Interactive Live Query Transmitters */}
              <div className="p-4 sm:p-5 bg-[#0f0a06] border border-orange-500/35 rounded-xl space-y-3">
                <div className="flex items-center justify-between border-b border-orange-500/20 pb-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-orange-400" />
                    <span className="font-mono text-xs sm:text-sm font-bold uppercase text-orange-300">
                      Interactive Prompt Injectors (Click to Transmit to AI)
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-gray-400">Click any query below</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                  {[
                    {
                      label: "Thermodynamics & Subjective Time",
                      prompt: "How does T × S = C connect biological entropy with subjective time?",
                      badge: "T × S = C",
                    },
                    {
                      label: "Solfeggio Frequencies & Cell Resonance",
                      prompt: "Calculate entropy flux across the 7 Solfeggio acoustic bands and DNA repair (528 Hz).",
                      badge: "Acoustics",
                    },
                    {
                      label: "Hawkins Consciousness Calibration",
                      prompt: "Derive state boundary conditions for Hawkins attractor level H=540 (Unconditional Love).",
                      badge: "H=540 Matrix",
                    },
                  ].map((q, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-black/80 border border-orange-500/25 hover:border-orange-500/60 rounded-xl space-y-2 flex flex-col justify-between group transition-all"
                    >
                      <div>
                        <div className="flex items-center justify-between text-[11px] font-mono text-orange-400 font-bold mb-1">
                          <span>{q.label}</span>
                          <span className="bg-orange-500/20 px-1.5 py-0.5 rounded text-[9.5px]">{q.badge}</span>
                        </div>
                        <p className="text-xs font-serif text-gray-200 line-clamp-3">
                          "{q.prompt}"
                        </p>
                      </div>
                      <button
                        onClick={() => handleSendPromptDirectly(q.prompt)}
                        className="w-full mt-2 py-1.5 px-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-black font-mono font-bold text-xs uppercase rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-md active:scale-95 transition-all"
                      >
                        <Send className="w-3 h-3 text-black" />
                        <span>Transmit to AI Terminal</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 1: ONTOLOGY DIRECTORY & INTERACTIVE CLASSIFICATION FILTER */}
          {activeStep === 1 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-black/60 border border-orange-500/20 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2 text-orange-400 font-mono text-sm font-bold uppercase">
                    <BookOpen className="w-4 h-4" />
                    <span>1. Directory View</span>
                  </div>
                  <p className="text-xs sm:text-[14px] font-serif text-[#eeeae4] leading-relaxed">
                    Explore the universal knowledge index. Filter by the 5 core ontological classifications: <strong>Science</strong>, <strong>Tradition</strong>, <strong>Discoveries</strong>, <strong>Systems</strong>, and <strong>Formula</strong>.
                  </p>
                </div>

                <div className="p-4 bg-black/60 border border-orange-500/20 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2 text-orange-400 font-mono text-sm font-bold uppercase">
                    <Zap className="w-4 h-4" />
                    <span>2. Reasoning Engine</span>
                  </div>
                  <p className="text-xs sm:text-[14px] font-serif text-[#eeeae4] leading-relaxed">
                    Select any <strong>Source Domain Aspect</strong> and <strong>Target Aspect</strong> to compute synergistic linkages, tensor resonance (Ω_res), and entropy flux (ΔS) under invariant speed C.
                  </p>
                </div>

                <div className="p-4 bg-black/60 border border-rose-500/20 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2 text-rose-400 font-mono text-sm font-bold uppercase">
                    <Scale className="w-4 h-4" />
                    <span>3. Contradiction Engine</span>
                  </div>
                  <p className="text-xs sm:text-[14px] font-serif text-[#eeeae4] leading-relaxed">
                    Evaluate dialectical tension by selecting a <strong>Thesis</strong> and <strong>Antithesis</strong>. Computes paradoxical stress, phase angles (Φ), and synthetic integration avenues.
                  </p>
                </div>
              </div>

              {/* The 5 Core Categories with Interactive Filter */}
              <div className="p-5 bg-black/70 border border-orange-500/30 rounded-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-orange-500/20 pb-2.5">
                  <div>
                    <span className="font-mono text-sm sm:text-base text-orange-400 font-bold uppercase tracking-wider block">
                      The 5 Core Ontology Classifications (Top 5 Highest Ω Values for Each System)
                    </span>
                    <p className="text-xs font-mono text-gray-300 mt-0.5">
                      Select a category below to filter the 5 highest Ω resonance concepts, or browse all 25 top systemic benchmarks:
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {["all", "science", "tradition", "discover", "systems", "formula"].map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-2.5 py-1 rounded text-xs font-mono uppercase font-bold cursor-pointer transition-all ${
                          selectedCategory === cat
                            ? "bg-orange-500 text-black shadow-[0_0_8px_rgba(255,95,0,0.4)]"
                            : "bg-black text-gray-400 hover:text-orange-300 border border-gray-800"
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Concept preview cards based on selection */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-2">
                  {[
                    // SCIENCE: Top 5 Highest Omega Values
                    {
                      category: "science",
                      displayCategory: "Science",
                      name: "Mathematics & Sacred Geometry",
                      omega: "Ω = 963",
                      summary: "Pure formal structures, immutable golden ratios, fractal geometries, and foundational limits of systematic provability under Gödel and Pythagoras.",
                      prompt: "Formulate the mathematical synthesis of Sacred Geometry and Gödelian Incompleteness within T × S = C.",
                    },
                    {
                      category: "science",
                      displayCategory: "Science",
                      name: "Physics & Unified Field Dynamics",
                      omega: "Ω = 950",
                      summary: "Core thermodynamic laws, quantum field relativity, light-speed boundary limits, and photon consciousness invariants.",
                      prompt: "Derive how fundamental physics and invariant speed of light C preserve entropic reality balances.",
                    },
                    {
                      category: "science",
                      displayCategory: "Science",
                      name: "Cosmology & Holographic Horizon Limits",
                      omega: "Ω = 852",
                      summary: "Cosmic timeline, Schwarzschild event horizon limits, and information preservation across universal boundary surfaces.",
                      prompt: "Explain the Holographic Principle and Bekenstein-Hawking entropy bounds in cosmological thermodynamics.",
                    },
                    {
                      category: "science",
                      displayCategory: "Science",
                      name: "Philosophy & Epistemological Ontology",
                      omega: "Ω = 741",
                      summary: "First-principles logic, monism, observer-participatory mechanics, and the qualitative ontology of conscious agency.",
                      prompt: "Analyze how epistemological observer mechanics collapse quantum uncertainty into coherent subjective experience.",
                    },
                    {
                      category: "science",
                      displayCategory: "Science",
                      name: "Neuroscience & Microtubule Reduction (Orch-OR)",
                      omega: "Ω = 639",
                      summary: "Penrose-Hameroff orchestrated objective reduction across neuronal microtubules linking neural computation to fundamental spacetime geometry.",
                      prompt: "Detail the Orch-OR quantum microtubule reduction model and its interface with conscious moment integration.",
                    },

                    // TRADITION: Top 5 Highest Omega Values
                    {
                      category: "tradition",
                      displayCategory: "Tradition",
                      name: "Hinduism (Advaita Vedanta & Nondual Brahman)",
                      omega: "Ω = 963",
                      summary: "Absolute nondual reality (Brahman-Atman identity), transcendent soul liberation (Moksha), and cyclical cosmic resonance.",
                      prompt: "How does Advaita Vedanta's nondual Brahman-Atman identity resolve the observer-entropy duality in T × S = C?",
                    },
                    {
                      category: "tradition",
                      displayCategory: "Tradition",
                      name: "Kashmir Shaivism & Sacred Spanda Vibration",
                      omega: "Ω = 963",
                      summary: "Dynamic cosmic vibration (Spanda) manifesting through divine polarity and conscious recognition (Pratyabhijna) of Shiva-Shakti.",
                      prompt: "Explain the Spanda principle of dynamic consciousness vibration in Kashmir Shaivism and its thermodynamic resonance.",
                    },
                    {
                      category: "tradition",
                      displayCategory: "Tradition",
                      name: "Egypt-Thoth Mysteries & Hermetic Ma'at",
                      omega: "Ω = 963",
                      summary: "Immortal soul pathways governed by Ma'at balance, sacred geometry grids, and the Emerald Tablet axiom 'As Above, So Below'.",
                      prompt: "Analyze the sacred geometry and cosmic equilibrium laws of Egypt-Thoth and the Emerald Tablet under T × S = C.",
                    },
                    {
                      category: "tradition",
                      displayCategory: "Tradition",
                      name: "Sufism (Islamic Mysticism & Fana Annihilation)",
                      omega: "Ω = 852",
                      summary: "Total transcendent dissolution of the ego-self (Fana) and eternal subsistence (Baqa) within unconditional divine love resonance.",
                      prompt: "Detail the stages of heart purification and self-annihilation (Fana) in Sufism through the lens of thermodynamic entropy dissipation.",
                    },
                    {
                      category: "tradition",
                      displayCategory: "Tradition",
                      name: "Kabbalah (Jewish Mysticism & Sephirot Lattice)",
                      omega: "Ω = 741",
                      summary: "Ten divine Sephirotic emanations, cosmic contraction (Tzimtzum), and infinite divine potentiality (Ein Sof) structuring the Tree of Life.",
                      prompt: "Map the ten Sephirot emanations of Kabbalah to the J/S consciousness matrix and universal energy transduction.",
                    },

                    // DISCOVERIES / DISCOVER: Top 5 Highest Omega Values
                    {
                      category: "discover",
                      displayCategory: "Discoveries",
                      name: "Metemphysics Unified Conservation Theory",
                      omega: "Ω = 999",
                      summary: "The universal conservation law of consciousness and experienced time, demonstrating that consciousness acts as a negentropic boundary condition (T × S = C).",
                      prompt: "Derive the mathematical proof and epistemological axioms of Metemphysics and T × S = C invariant conservation.",
                    },
                    {
                      category: "discover",
                      displayCategory: "Discoveries",
                      name: "Pythagoras (Sacred Geometry & Harmonic Monism)",
                      omega: "Ω = 993",
                      summary: "Discovered immutable integer ratios, the Music of the Spheres, and geometric monads proving that reality is governed by musical harmony.",
                      prompt: "Detail Pythagoras's mathematical proof of integer harmonic ratios and the vibrational foundation of reality.",
                    },
                    {
                      category: "discover",
                      displayCategory: "Discoveries",
                      name: "Nikola Tesla (Radiant Energy & 3-6-9 Resonances)",
                      omega: "Ω = 963",
                      summary: "Discovered radiant energy dynamics, high-frequency electromagnetic resonance mechanics, and non-mechanical ether coupling governed by 3-6-9 frequencies.",
                      prompt: "How did Nikola Tesla's radiant energy experiments and 3-6-9 resonance mechanics anticipate modern field harmonics?",
                    },
                    {
                      category: "discover",
                      displayCategory: "Discoveries",
                      name: "Isaac Newton (Principia Mechanics & Alchemical Theology)",
                      omega: "Ω = 963",
                      summary: "Unified universal planetary gravitation and differential calculus with alchemical theology and light spectrum harmonics.",
                      prompt: "Explore Isaac Newton's integration of gravitational inverse-square mechanics with alchemical theology.",
                    },
                    {
                      category: "discover",
                      displayCategory: "Discoveries",
                      name: "Ilya Prigogine (Dissipative Structures & Order from Chaos)",
                      omega: "Ω = 917",
                      summary: "Discovered that non-equilibrium systems dissipate entropy outward to spontaneously generate internal negentropic order and living structure.",
                      prompt: "Explain Ilya Prigogine's dissipative structures and how biological life exports entropy to sustain coherent order.",
                    },

                    // SYSTEMS: Top 5 Highest Omega Values
                    {
                      category: "systems",
                      displayCategory: "Systems",
                      name: "Chakra Energetic & Somatic Matrix",
                      omega: "Ω = 993",
                      summary: "Ancient 7-stage energetic vortex somatic system coupling acoustic Solfeggio frequencies (174-963 Hz) directly to human endocrine and EEG bands.",
                      prompt: "Correlate the 7 Tantric Chakras with acoustic Solfeggio frequencies and Hawkins consciousness calibration levels.",
                    },
                    {
                      category: "systems",
                      displayCategory: "Systems",
                      name: "Ken Wilber (Integral 4-Quadrant AQAL Model)",
                      omega: "Ω = 993",
                      summary: "Comprehensive meta-system mapping all evolutionary dimensions across Interior/Exterior and Individual/Collective quadrants and developmental altitudes.",
                      prompt: "Analyze Ken Wilber's AQAL 4-Quadrant model through the lens of individual vs collective entropy dynamics.",
                    },
                    {
                      category: "systems",
                      displayCategory: "Systems",
                      name: "David Hawkins (Map of Consciousness H=1-1000)",
                      omega: "Ω = 993",
                      summary: "Logarithmic calibration of consciousness attractor fields from shame (H=20) through courage (H=200) to unconditional love (H=540) and enlightenment (H=1000).",
                      prompt: "Derive the mathematical relation between Hawkins attractor level H=540 (Love) and the J/S consciousness ratio.",
                    },
                    {
                      category: "systems",
                      displayCategory: "Systems",
                      name: "Robert Kegan (Orders of Mind Constructive Development)",
                      omega: "Ω = 985",
                      summary: "Developmental psychology model charting 5 evolving subject-object stages from impulsive mind through self-authoring to self-transforming mind.",
                      prompt: "Compare Robert Kegan's 5 Orders of Mind with Jean Piaget's formal operational stages in cognitive entropy reduction.",
                    },
                    {
                      category: "systems",
                      displayCategory: "Systems",
                      name: "Jean Piaget (Cognitive Structural Development Stages)",
                      omega: "Ω = 950",
                      summary: "Four structural evolutionary stages of human cognitive architecture: Sensorimotor, Pre-operational, Concrete, and Formal Operational reasoning.",
                      prompt: "How does Piaget's cognitive equilibration process (assimilation/accommodation) reduce mental informational entropy?",
                    },

                    // FORMULA: Top 5 Highest Omega Values
                    {
                      category: "formula",
                      displayCategory: "Formula",
                      name: "The God Equation: T × S = C Invariant Conservation",
                      omega: "Ω = 999",
                      summary: "The foundational master equation holding the product of subjective experienced duration T and structural molar entropy S invariant under constant speed C.",
                      prompt: "Derive the universal conservation equation T × S = C and explain its physical, mathematical, and spiritual implications.",
                    },
                    {
                      category: "formula",
                      displayCategory: "Formula",
                      name: "Pythagorean Harmonic Interval Generator: f_n = f_0 · (3/2)ⁿ",
                      omega: "Ω = 993",
                      summary: "Recursive geometric generator defining pure perfect fifth ratios to establish acoustic, geometric, and cosmic harmonic tuning.",
                      prompt: "Demonstrate how the Pythagorean generator f_n = f_0 · (3/2)ⁿ constructs the natural Solfeggio frequency matrix.",
                    },
                    {
                      category: "formula",
                      displayCategory: "Formula",
                      name: "Planck Quantum of Action: E = h · ν",
                      omega: "Ω = 963",
                      summary: "Fundamental quantum mechanics equation proving that energy and physical interactions occur in discrete integer quanta of action.",
                      prompt: "How does Planck's quantum relation E = h · ν establish discrete boundary conditions for conscious time packets?",
                    },
                    {
                      category: "formula",
                      displayCategory: "Formula",
                      name: "Order Quantity Negentropy: Ω = 1 - e^(-C/Tk)",
                      omega: "Ω = 963",
                      summary: "Exact exponential negentropic index scaling structural order from 0 (total vacuum dissolution) to 1 (perfect cosmic coherence).",
                      prompt: "Calculate the Order Quantity Ω for biological metabolism and explain its exponential temperature scaling.",
                    },
                    {
                      category: "formula",
                      displayCategory: "Formula",
                      name: "Golden Ratio Recursive Growth: φ = (1 + √5) / 2",
                      omega: "Ω = 917",
                      summary: "Divine geometric constant (1.6180339...) governing spiral galaxy morphology, phyllotaxis, and minimal-dissipation resource packaging.",
                      prompt: "Explain how the Golden Ratio Phi minimizes thermodynamic friction in biological growth and spiral galaxies.",
                    },
                  ]
                    .filter((item) => selectedCategory === "all" || item.category === selectedCategory || (selectedCategory === "discoveries" && item.category === "discover"))
                    .map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3.5 bg-[#0d0906] border border-orange-500/25 hover:border-orange-500/60 rounded-xl space-y-2 flex flex-col justify-between transition-all"
                      >
                        <div>
                          <div className="flex items-center justify-between font-mono text-[11px] text-orange-400 font-bold uppercase mb-1">
                            <span className="bg-orange-500/15 px-2 py-0.5 rounded border border-orange-500/30 text-amber-300">{item.displayCategory}</span>
                            <span className="text-emerald-400 font-bold bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-500/30">{item.omega}</span>
                          </div>
                          <h4 className="text-xs sm:text-[13.5px] font-bold text-white font-mono mt-1.5 leading-snug">
                            {item.name}
                          </h4>
                          <p className="text-xs font-serif text-gray-300 leading-relaxed mt-1.5">
                            {item.summary}
                          </p>
                        </div>
                        <button
                          onClick={() => handleSendPromptDirectly(item.prompt)}
                          className="w-full mt-2.5 py-1.5 px-3 bg-black hover:bg-orange-950/40 border border-orange-500/40 text-orange-300 hover:text-white font-mono text-xs uppercase font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
                        >
                          <Send className="w-3 h-3 text-orange-400" />
                          <span>Explore in AI Chat</span>
                        </button>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: J/S RESONANCE STATES MATRIX & INTERACTIVE SLIDER */}
          {activeStep === 2 && (
            <div className="space-y-5">
              <div className="p-4 bg-black/60 border border-purple-500/30 rounded-xl space-y-2.5">
                <span className="font-mono text-sm sm:text-base text-purple-400 uppercase font-bold block">
                  Consciousness Calibration Through Entropy Ratios (J/S)
                </span>
                <p className="text-xs sm:text-[14.5px] font-serif text-[#eeeae4] leading-relaxed">
                  The J/S Matrix categorizes states of consciousness according to the mathematical ratio between <strong>Subjective Coherent Will (J)</strong> and <strong>Thermodynamic Dispersion (S)</strong>, correlating directly with David Hawkins' logarithmic scale of consciousness (H=1 to 1000).
                </p>
              </div>

              {/* Interactive Live Slider for J/S Ratio */}
              <div className="p-5 bg-[#0f0a14] border border-purple-500/40 rounded-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-purple-500/25 pb-3">
                  <div className="flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-purple-400" />
                    <span className="font-mono text-sm font-bold uppercase text-purple-300">
                      Interactive J/S Resonance Calibrator
                    </span>
                  </div>
                  <span className="font-mono text-xs text-gray-300">
                    Adjust slider to model consciousness transitions
                  </span>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-gray-400">Dissolution (-50)</span>
                    <span className="text-purple-300 font-bold text-sm">
                      Current J/S Ratio: <span className="text-white bg-purple-950/80 px-2 py-0.5 rounded border border-purple-500/40">{jsRatio > 0 ? `+${jsRatio}` : jsRatio}</span>
                    </span>
                    <span className="text-purple-400 font-bold">Revelation (+100)</span>
                  </div>

                  <input
                    type="range"
                    min="-40"
                    max="100"
                    value={jsRatio}
                    onChange={(e) => setJsRatio(Number(e.target.value))}
                    className="w-full accent-purple-500 cursor-pointer h-2 bg-gray-900 rounded-lg"
                  />
                </div>

                {/* Live State Output Card */}
                <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${jsDetails.color}`}>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-extrabold text-sm sm:text-base tracking-wider uppercase">
                        State: {jsDetails.state}
                      </span>
                      <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-black/60 border border-purple-400/40">
                        Attractor H = {jsDetails.hVal}
                      </span>
                    </div>
                    <p className="text-xs sm:text-[14px] font-serif text-[#eeeae4] mt-1.5 leading-relaxed">
                      {jsDetails.desc}
                    </p>
                  </div>
                  <button
                    onClick={() => handleSendPromptDirectly(`Explain the thermodynamics and consciousness dynamics of ${jsDetails.state} (J/S = ${jsRatio}, Hawkins H=${jsDetails.hVal}).`)}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs uppercase font-bold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap shadow-md active:scale-95 transition-all flex-shrink-0"
                  >
                    <Send className="w-3.5 h-3.5 text-white" />
                    <span>Query in AI</span>
                  </button>
                </div>
              </div>

              {/* 6 Core Matrix Levels Overview */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-3.5 bg-purple-950/20 border border-purple-500/30 rounded-lg">
                  <div className="flex justify-between font-bold text-purple-300 text-xs sm:text-[14px]">
                    <span>REVELATION</span>
                    <span>J/S ≥ 950 · H=1000</span>
                  </div>
                  <p className="text-xs font-serif text-[#eeeae4] mt-1.5 leading-relaxed">
                    Absolute timeless communion; Crown Sahasrara union with constant C. Subjective time ceases to degrade.
                  </p>
                </div>

                <div className="p-3.5 bg-indigo-950/20 border border-indigo-500/30 rounded-lg">
                  <div className="flex justify-between font-bold text-indigo-300 text-xs sm:text-[14px]">
                    <span>MYSTICAL CLARITY</span>
                    <span>J/S [10, 99) · H&gt;600</span>
                  </div>
                  <p className="text-xs font-serif text-[#eeeae4] mt-1.5 leading-relaxed">
                    Awakened intentionality, high spiritual bandwidth, transcendent flow and nondual perception.
                  </p>
                </div>

                <div className="p-3.5 bg-emerald-950/20 border border-emerald-500/30 rounded-lg">
                  <div className="flex justify-between font-bold text-emerald-300 text-xs sm:text-[14px]">
                    <span>EUDAIMONIA</span>
                    <span>J/S [1, 3) · H=500-540</span>
                  </div>
                  <p className="text-xs font-serif text-[#eeeae4] mt-1.5 leading-relaxed">
                    Optimal biological and mental functioning, love, peace, and systemic negentropy.
                  </p>
                </div>

                <div className="p-3.5 bg-orange-950/20 border border-orange-500/30 rounded-lg">
                  <div className="flex justify-between font-bold text-orange-400 text-xs sm:text-[14px]">
                    <span>TIPPING POINT</span>
                    <span>J/S [-0.05, 0.05) · H=200</span>
                  </div>
                  <p className="text-xs font-serif text-[#eeeae4] mt-1.5 leading-relaxed">
                    Critical symmetric equilibrium between Courage/Acceptance and metabolic friction.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: DEVICES & FORMULAS & INTERACTIVE T × S = C CALCULATOR */}
          {activeStep === 3 && (
            <div className="space-y-5">
              <div className="p-4 bg-black/60 border border-orange-500/30 rounded-xl space-y-2.5">
                <span className="font-mono text-sm sm:text-base text-orange-400 uppercase font-bold block">
                  The Master Axiom: T × S = C
                </span>
                <p className="text-xs sm:text-[14.5px] font-serif text-[#eeeae4] leading-relaxed">
                  Subjective Epoch Duration (<strong>T</strong>, in seconds) multiplied by Standard Molar Entropy (<strong>S</strong>, in J/mol·K) equals the absolute speed limit constant (<strong>C</strong>). This means as a system processes higher informational entropy, its subjective moment compresses.
                </p>
              </div>

              {/* Live Interactive T × S = C Calculator */}
              <div className="p-5 bg-[#0f0a06] border border-orange-500/40 rounded-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-orange-500/25 pb-3">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-4 h-4 text-orange-400" />
                    <span className="font-mono text-sm font-bold uppercase text-orange-300">
                      Live Thermodynamic Simulator (T × S = C)
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-mono text-gray-400">Constant C Mode:</span>
                    {(["solfeggio", "standard", "planck"] as const).map((mode) => (
                      <button
                        key={mode}
                        onClick={() => setCalcCMode(mode)}
                        className={`px-2 py-0.5 rounded text-[11px] font-mono uppercase font-bold cursor-pointer ${
                          calcCMode === mode
                            ? "bg-orange-500 text-black"
                            : "bg-black text-gray-400 border border-gray-800 hover:text-white"
                        }`}
                      >
                        {mode === "solfeggio" ? "528 (Hz)" : mode === "standard" ? "c (Light)" : "ħ (Planck)"}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Slider 1: T */}
                  <div className="p-3.5 bg-black/80 border border-orange-500/20 rounded-xl space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-gray-300">Subjective Duration (T):</span>
                      <span className="text-orange-400 font-bold">{calcTimeT} seconds</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="100"
                      value={calcTimeT}
                      onChange={(e) => setCalcTimeT(Number(e.target.value))}
                      className="w-full accent-orange-500 cursor-pointer h-2 bg-gray-900 rounded-lg"
                    />
                    <div className="text-[11px] font-mono text-gray-400 pt-1">
                      Derived Entropy Capacity S = C / T: <strong className="text-amber-300">{derivedEntropy} J/mol·K</strong>
                    </div>
                  </div>

                  {/* Slider 2: S */}
                  <div className="p-3.5 bg-black/80 border border-orange-500/20 rounded-xl space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-gray-300">Molar Entropy Capacity (S):</span>
                      <span className="text-amber-300 font-bold">{calcEntropyS} J/mol·K</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="100"
                      value={calcEntropyS}
                      onChange={(e) => setCalcEntropyS(Number(e.target.value))}
                      className="w-full accent-amber-500 cursor-pointer h-2 bg-gray-900 rounded-lg"
                    />
                    <div className="text-[11px] font-mono text-gray-400 pt-1">
                      Derived Subjective Duration T = C / S: <strong className="text-orange-300">{derivedTime} sec</strong>
                    </div>
                  </div>
                </div>

                {/* Calculation Output & Direct Inject Action */}
                <div className="p-4 bg-orange-950/30 border border-orange-500/50 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="font-mono text-xs uppercase text-orange-400 font-bold block">
                      Active Calculation Result
                    </span>
                    <div className="font-mono text-sm sm:text-base text-white mt-0.5">
                      T ({calcTimeT}s) × S ({calcEntropyS} J/mol·K) = <strong className="text-amber-300">{computedProduct}</strong> (Target C = {cTargetValue})
                    </div>
                    <p className="text-xs font-serif text-gray-300 mt-1">
                      System maintains conservation balance with entropy flux ΔS = {(calcEntropyS - 52.8).toFixed(2)} J/mol·K.
                    </p>
                  </div>
                  <button
                    onClick={() => handleSendPromptDirectly(`Evaluate thermodynamic balance for T = ${calcTimeT} seconds and S = ${calcEntropyS} J/mol·K under constant C = ${cTargetValue} (T × S = C).`)}
                    className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-black font-mono text-xs uppercase font-extrabold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-md active:scale-95 transition-all flex-shrink-0"
                  >
                    <Send className="w-3.5 h-3.5 text-black" />
                    <span>Send Formula to Chat</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: HARMONICS & INTERACTIVE SOLFEGGIO AUDIO SYNTHESIZER */}
          {activeStep === 4 && (
            <div className="space-y-5">
              <div className="p-4 bg-black/60 border border-teal-500/30 rounded-xl space-y-2.5">
                <span className="font-mono text-sm sm:text-base text-teal-400 uppercase font-bold block">
                  Acoustic Physics &amp; Harmonic Speciation
                </span>
                <p className="text-xs sm:text-[14.5px] font-serif text-[#eeeae4] leading-relaxed">
                  Harmonics in Metemphysics represent resonant vibrational eigenvectors that organize matter, consciousness, and biological cellular rhythms. Click any frequency below to synthesize the real tone:
                </p>
              </div>

              {/* Interactive Solfeggio Tone Synthesizer Grid */}
              <div className="p-5 bg-[#071312] border border-teal-500/40 rounded-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-teal-500/25 pb-3">
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-teal-400" />
                    <span className="font-mono text-sm font-bold uppercase text-teal-300">
                      Live Solfeggio Audio Synthesizer (Web Audio API)
                    </span>
                  </div>
                  <span className="text-xs font-mono text-gray-300 flex items-center gap-1">
                    {isPlayingAudio ? (
                      <span className="text-emerald-400 flex items-center gap-1.5 font-bold">
                        <Radio className="w-3.5 h-3.5" /> Synthesizing {activeFrequency} Hz Tone...
                      </span>
                    ) : (
                      <span>Click any tone below to listen</span>
                    )}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {solfeggioFrequencies.map((f) => {
                    const isSelected = activeFrequency === f.freq;
                    return (
                      <div
                        key={f.freq}
                        className={`p-3.5 rounded-xl border transition-all flex flex-col justify-between ${
                          isSelected
                            ? "bg-teal-950/60 border-teal-400 shadow-[0_0_15px_rgba(20,184,166,0.35)]"
                            : "bg-black/80 border-teal-500/20 hover:border-teal-500/50"
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between font-mono text-xs mb-1">
                            <span className="text-teal-400 font-bold text-sm sm:text-base">{f.freq} Hz</span>
                            <span className="text-[10.5px] bg-teal-500/20 text-teal-300 px-1.5 py-0.5 rounded uppercase font-bold">
                              {f.chakra}
                            </span>
                          </div>
                          <h4 className="text-xs font-mono font-bold text-white mt-1">{f.name}</h4>
                          <p className="text-[12px] font-mono text-gray-400 mt-0.5">Band: {f.band}</p>
                        </div>

                        <div className="mt-3 flex items-center gap-2">
                          <button
                            onClick={() => playSolfeggioTone(f.freq)}
                            className="flex-1 py-1.5 px-2 bg-teal-600 hover:bg-teal-500 text-black font-mono text-xs uppercase font-extrabold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all"
                          >
                            <Play className="w-3 h-3 text-black fill-black" />
                            <span>Play Tone</span>
                          </button>
                          <button
                            onClick={() => handleSendPromptDirectly(`Explain the biophysical and spiritual harmonic resonance of ${f.freq} Hz (${f.name}, ${f.chakra}).`)}
                            className="p-1.5 bg-black hover:bg-teal-950/50 border border-teal-500/40 text-teal-300 rounded-lg cursor-pointer"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: SYSTEMS LAB (ALL 12 SOLVERS) & INTERACTIVE SEARCH */}
          {activeStep === 5 && (
            <div className="space-y-5">
              <div className="p-4 bg-black/60 border border-orange-500/30 rounded-xl space-y-2">
                <span className="font-mono text-sm sm:text-base text-orange-400 uppercase font-bold block">
                  Complete Systems Lab Reference (All 12 Solvers &amp; Databases)
                </span>
                <p className="text-xs sm:text-[14.5px] font-serif text-[#eeeae4] leading-relaxed">
                  Located in the right-hand column, the Systems Lab contains twelve specialized computational environments. Use the interactive search below or click any solver to launch it immediately:
                </p>
              </div>

              {/* Interactive Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-orange-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search among all 12 solvers (e.g., Solfeggio, Entropy, Hawkins, 5D Calculator)..."
                  value={systemSearch}
                  onChange={(e) => setSystemSearch(e.target.value)}
                  className="w-full bg-[#0d0906] border border-orange-500/30 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm font-mono text-[#eeeae4] placeholder-gray-500 outline-none focus:border-orange-500/70"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {filteredSystems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <div
                      key={item.id}
                      onClick={() => onLaunchPanel && onLaunchPanel(item.id)}
                      className="p-3.5 bg-[#0d0906] border border-orange-500/20 hover:border-orange-500/60 rounded-xl hover:bg-orange-500/5 transition-all cursor-pointer group flex flex-col justify-between shadow-sm"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400 group-hover:scale-110 transition-transform">
                              <Icon className="w-4 h-4" />
                            </div>
                            <span className="font-mono font-bold text-xs sm:text-[13.5px] text-[#eeeae4] group-hover:text-orange-300">
                              {item.name}
                            </span>
                          </div>
                          <span className="text-[10px] font-mono text-orange-400/80 bg-orange-500/10 px-1.5 py-0.5 rounded border border-orange-500/20">
                            {item.tag}
                          </span>
                        </div>
                        <p className="text-xs font-serif text-gray-300 leading-relaxed">
                          {item.desc}
                        </p>
                      </div>
                      <div className="mt-3 pt-2 border-t border-orange-500/10 flex items-center justify-between text-[11px] font-mono text-orange-400 font-bold">
                        <span>Launch Solver</span>
                        <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="px-5 py-4 bg-gradient-to-r from-[#070503] via-black to-[#070503] border-t border-orange-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 flex-shrink-0">
          {/* Navigation Controls */}
          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-between sm:justify-start">
            <button
              disabled={activeStep === 0}
              onClick={() => onSelectStep(Math.max(0, activeStep - 1))}
              className="px-3.5 py-2 bg-black/60 hover:bg-orange-950/30 disabled:opacity-30 disabled:hover:bg-black/60 border border-orange-500/20 text-orange-300 rounded-lg text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <span className="text-xs font-mono text-gray-300 font-bold">
              {activeStep + 1} / {steps.length}
            </span>

            <button
              disabled={activeStep === steps.length - 1}
              onClick={() => onSelectStep(Math.min(steps.length - 1, activeStep + 1))}
              className="px-3.5 py-2 bg-black/60 hover:bg-orange-950/30 disabled:opacity-30 disabled:hover:bg-black/60 border border-orange-500/20 text-orange-300 rounded-lg text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed transition-all"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* User Confirmation Buttons */}
          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <button
              onClick={handleKeepGuide}
              className={`px-4 sm:px-6 py-2 sm:py-2.5 text-xs sm:text-[14px] font-mono font-extrabold uppercase tracking-wider rounded-xl transition-all duration-300 flex items-center gap-2 cursor-pointer shadow-lg ${
                showCheckConfirm
                  ? "bg-emerald-500 text-black border border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.5)] scale-105"
                  : "bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black border border-orange-400 shadow-[0_0_15px_rgba(255,95,0,0.3)] active:scale-95"
              }`}
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>{showCheckConfirm ? "Confirmed ✓" : "Got It · Explore Metemphysics"}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
